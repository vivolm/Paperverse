let shapeShifterAni;

function setup() {
	new Canvas(375, 500);

	//                loadAni(...files)
	shapeShifterAni = loadAni(
		'Animation/1.png',
		'Animation/2.png',
		'Animation/3.png',
		'Animation/4.png',
		'Animation/5.png', 
        'Animation/6.png', 
        'Animation/7.png', 
        'Animation/8.png', 
        'Animation/9.png',
        'Animation/10.png',
        'Animation/11.png'
	);

	shapeShifterAni.frameDelay = 5;
}

function draw() {
	clear();
	animation(shapeShifterAni, 375/2, 500/2);
    text('Frame-Animation', 20,20);
}