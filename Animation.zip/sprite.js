let splatAni;

function preload(){
  //         loadAni(spriteSheet, atlas) - in preload wegen wiederholter Fehlermeldung
  splatAni = loadAni('Animation/spritesheet(1).png', {
		width: 375, height: 500, frames: 11
	});
}

function setup() {
	new Canvas(375, 500);	
}

function draw() {
	clear();
	animation(splatAni, 375/2, 500/2);
    text('Sprite-Animation', 20,20);
}