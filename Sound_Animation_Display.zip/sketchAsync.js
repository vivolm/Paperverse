let stickman;
let idle;
let angry;

//to ensure animations change accordingly
let upLocked = false;

function preload(){  
  //Create Sprite Object and set position
  stickman = new Sprite(175/2, 248/2);
  
  //Load Animations and store them in variables
  angry = loadAni("Assets/angry.png", {width: 175, height: 248, frames: 11});
  lose = loadAni("Assets/lose.png", {width: 175, height: 248, frames: 17});
  note = loadAni("Assets/note.png", {width: 175, height: 248, frames: 14});
  idle = loadAni("Assets/idle.png", {width: 175, height: 248, frames: 18});
  
  nuhuh = loadSound("angry.mp3");
  nuhuh.volume = 0.5;
  
  //Store Animations in Sprite Object with Aliases for easy Access and set fps
  stickman.addAni("angry", angry);
  stickman.addAni("lose", lose);
  stickman.addAni("note", note);
  //default is probably last inserted animation
  stickman.addAni("idle", idle);
  stickman.anis.frameDelay = 8;
}

function setup(){
  new Canvas(800, 248);
}

function draw(){
  clear();
  background("grey");
  //Only call ONCE no continous true input for calls or sequence won't start correctly
  //mad() function can also be called with singular call in draw
  if (!upLocked) {
    mad();
    console.log("mad is running");
    upLocked = true;
  }
}


async function mad(){
  //Separate the animation for 
  nuhuh.loop();
  //play angry once
  await stickman.changeAni("angry");
  nuhuh.stop();
  
  //play lose once
  await stickman.changeAni(["note", "lose"]);
  
  //make sure the looping stops when gameState is changed
  if(upLocked){
    console.log("return");
    return mad();
  }
}