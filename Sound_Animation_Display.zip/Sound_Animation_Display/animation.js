//Variable for Asset Sprite
let asset;

//Variables for Animations
let idleAni;
let noteAni;
let thinkAni;
let waitAni;
let angryAni;
let winAni;
let loseAni;
let climbAni;
let walkAni;
let waveAnim;

//Variables for Sounds;
let noteSoun;
let thinkSoun;
let waitSoun;
let angrySoun;
let winSoun;
let loseSoun;
let climbSoun;
let walkSoun;
let waveSoun;

//Counter for Animation Change
let changeAni = 0;
let lastAni = 9;


function preload(){  
  //Create Sprite Object and set position
  asset = new Sprite(175/2, 248/2);
  
  //Load Animations and store them in variables
  waveAni = loadAni("Assets/wave.png", {width: 175, height: 248, frames: 2});
  walkAni = loadAni("Assets/walk.png", {width: 175, height: 248, frames: 4});
  climbAni = loadAni("Assets/climb.png", {width: 175, height: 248, frames: 2});
  loseAni = loadAni("Assets/lose.png", {width: 175, height: 248, frames: 17});
  winAni =  loadAni("Assets/win.png", {width: 175, height: 248, frames: 11});
  angryAni = loadAni("Assets/angry.png", {width: 175, height: 248, frames: 11});
  waitAni = loadAni("Assets/wait.png", {width: 175, height: 248, frames: 10});
  thinkAni = loadAni("Assets/think.png", {width: 175, height: 248, frames: 11});
  noteAni = loadAni("Assets/note.png", {width: 175, height: 248, frames: 14});
  idleAni = loadAni("Assets/idle.png", {width: 175, height: 248, frames: 18});
  
  //Store Animations in Sprite Object with Aliases for easy Access and set fps
  asset.addAni("wave", waveAni);
  asset.addAni("walk", walkAni);
  asset.addAni("climb", climbAni);
  asset.addAni("lose", loseAni);
  asset.addAni("win", winAni);
  asset.addAni("angry", angryAni);
  asset.addAni("wait", waitAni);
  asset.addAni("think", thinkAni);
  asset.addAni("note", noteAni);
  asset.addAni("idle", idleAni);
  asset.anis.frameDelay = 9;
}

function setup(){
  new Canvas(800, 248);
}

function draw(){
  clear();
  console.log(changeAni + "/" + lastAni);
  
  if(changeAni == 0){
    asset.changeAni("idle");
  }
  else if(changeAni == 1){
    asset.changeAni("note");
  }
  else if(changeAni == 2){
    asset.changeAni("think");
  }
  else if(changeAni == 3){
    asset.changeAni("wait");
  }
  else if(changeAni == 4){
    asset.changeAni("angry");
  }
  else if(changeAni == 5){
    asset.changeAni("win");
  }
  else if(changeAni == 6){
    asset.changeAni("lose");
  }
  else if(changeAni == 7){
    asset.changeAni("climb");
  }
  else if(changeAni == 8){
    asset.changeAni("walk");
  }
  else if(changeAni == 9){
    asset.changeAni("wave");
  }
}


//Function for changing Animations and Sounds
function keyPressed(){
  if(kb.pressing('right')){
    if(changeAni < lastAni){
      asset.ani.frame = 0;
      changeAni++;
    }else{
      asset.ani.frame = 0;
      changeAni = 0;
    }
  }
  
  if(kb.pressing('left')){
    if(changeAni > 0){
      asset.ani.frame = 0;
      changeAni--;
    }else{
      asset.ani.frame = 0;
      changeAni = lastAni;
    }
  }
}



