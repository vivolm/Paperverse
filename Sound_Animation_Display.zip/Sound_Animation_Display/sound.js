//Variables for Sounds;
let angrySoun;
let failSoun;
let thinkSoun;
let insertSoun;
let portalSoun;
let snakeIdSoun;
let snakeDeSoun;
let writeSoun;
let noteSoun;
let tappSoun;
let gateSoun;
let walkSoun;
let winSoun;
let waveSoun;


//make sure call is only once
let aLock = false;
let sLock = false;
let dLock = false;
let fLock = false;
let gLock = false;
let hLock = false;
let jLock = false;
let kLock = false;
let lLock = false;
let yLock = false;
let xLock = false;
let cLock = false;
let vLock = false;
let bLock = false;

//show active Sound on Canvas
let activeSound;


function preload(){  
  //load the sounds
  angrySoun = loadSound("Sounds/angry.mp3");
  failSoun = loadSound("Sounds/fail.mp3");
  thinkSoun = loadSound("Sounds/think.mp3");
  insertSoun = loadSound("Sounds/insert.mp3");
  portalSoun = loadSound("Sounds/portal.mp3");
  snakeIdSoun = loadSound("Sounds/snakeId.mp3");
  snakeDeSoun = loadSound("Sounds/snakeDe.mp3");
  writeSoun = loadSound("Sounds/climb.mp3");
  noteSoun = loadSound("Sounds/note.mp3");
  tappSoun = loadSound("Sounds/tapp.mp3");
  gateSoun = loadSound("Sounds/gate.mp3");
  walkSoun = loadSound("Sounds/walk.mp3");
  winSoun = loadSound("Sounds/win.mp3");
  waveSoun = loadSound("Sounds/wave.mp3");
}

function setup(){
  new Canvas(300, 350);
}

function draw(){
  clear();
  
  //Control Panel
  noFill();
  strokeWeight(5);
  stroke(0);
  rect(0, 0, width, height);
  
  textSize(30);
  noStroke();
  fill(0);
  textAlign(CENTER);
  textStyle(BOLD);
  text(key + ": " + activeSound, width/2, width/7);
  
  textSize(18);
  text("PRESS SPACE [  ]", width/2, width/10+28*10);
  text("TO END ALL SOUNDS! ", width/2, width/10+28*11);
  
  //Table with keys
  textStyle(NORMAL);
  textAlign(RIGHT);
  text("angry  :  a ", width/2, width/10+28*2);
  text("fail  :  s ", width/2, width/10+28*3);
  text("think  :  d ", width/2, width/10+28*4);
  text("insert  :  f ", width/2, width/10+28*5);
  text("portal  :  g ", width/2, width/10+28*6);
  text("snake idle  :  h ", width/2, width/10+28*7);
  text("snake death  :  j ", width/2, width/10+28*8);
  
  text("climb  :  k ", width-width/10, width/10+28*2);
  text("note  :  l ", width-width/10, width/10+28*3);
  text("tapp  :  y ", width-width/10, width/10+28*4);
  text("gate  :  x ", width-width/10, width/10+28*5);
  text("walk  :  c ", width-width/10, width/10+28*6);
  text("win  :  v ", width-width/10, width/10+28*7);
  text("wave  :  b ", width-width/10, width/10+28*8);
  
  
  //If Anweisungen für die Tasten und Sounds
  if(key === "a" && !aLock){
    angrySoun.play();
    activeSound = "angrySoun";
    console.log(activeSound + " is active");
    aLock = true;
  }
  
  if(key === "s" && !sLock){
    failSoun.play();
    activeSound = "failSoun";
    console.log(activeSound + " is active");
    sLock = true;
  }
  
  if(key === "d" && !dLock){
    thinkSoun.play();
    activeSound = "thinkSoun";
    console.log(activeSound + " is active");
    dLock = true;
  }
  
  if(key === "f" && !fLock){
    insertSoun.play();
    activeSound = "insertSoun";
    console.log(activeSound + " is active");
    fLock = true;
  }
  
  if(key === "g" && !gLock){
    portalSoun.play();
    activeSound = "portalSoun";
    console.log(activeSound + " is active");
    gLock = true;
  }
  
  if(key === "h" && !hLock){
    snakeIdSoun.play();
    activeSound = "snakeIdSoun";
    console.log(activeSound + " is active");
    hLock = true;
  }
  
  if(key === "j" && !jLock){
    snakeDeSoun.play();
    activeSound = "snakeDeSoun";
    console.log(activeSound + " is active");
    jLock = true;
  }
  
  if(key === "k" && !kLock){
    writeSoun.play();
    activeSound = "writeSoun";
    console.log(activeSound + " is active");
    kLock = true;
  }
  
  if(key === "l" && !lLock){
    noteSoun.play();
    activeSound = "noteSoun";
    console.log(activeSound + " is active");
    lLock = true;
  }
  
  if(key === "y" && !yLock){
    tappSoun.play();
    activeSound = "tappSoun";
    console.log(activeSound + " is active");
    yLock = true;
  }
  
  if(key === "x" && !xLock){
    gateSoun.play();
    activeSound = "gateSoun";
    console.log(activeSound + " is active");
    xLock = true;
  }
  
  if(key === "c" && !cLock){
    walkSoun.play();
    activeSound = "walkSoun";
    console.log(activeSound + " is active");
    cLock = true;
  }
  
  if(key === "v" && !vLock){
    winSoun.play();
    activeSound = "winSoun";
    console.log(activeSound + " is active");
    vLock = true;
  }
  
  if(key === "b" && !bLock){
    waveSoun.play();
    activeSound = "waveSoun";
    console.log(activeSound + " is active");
    bLock = true;
  }
}


//Function to be able to replay sounds - press when sound si over or else overlap!!!
function keyPressed(){
  aLock = false;
  sLock = false;
  dLock = false;
  fLock = false;
  gLock = false;
  hLock = false;
  jLock = false;
  kLock = false;
  lLock = false;
  yLock = false;
  xLock = false;
  cLock = false;
  vLock = false;
  bLock = false;
  
  
  //Hard reset for all sounds to stop - press spacebar
  if(key === " "){
    angrySoun.stop();
    failSoun.stop();
    thinkSoun.stop();
    insertSoun.stop();
    portalSoun.stop();
    snakeIdSoun.stop();
    snakeDeSoun.stop();
    writeSoun.stop();
    noteSoun.stop();
    tappSoun.stop();
    gateSoun.stop();
    walkSoun.stop();
    winSoun.stop();
    waveSoun.stop();
    
    activeSound = "resetAll"
  }
}
