let stickman;
let idle;
let angry;
let gameState = true;

function preload(){  
  //Create Sprite Object and set position
  stickman = new Sprite(175/2, 248/2);
  
  //Load Animations and store them in variables
  angry = loadAni("Assets/angry.png", {width: 175, height: 248, frames: 11});
  lose = loadAni("Assets/lose.png", {width: 175, height: 248, frames: 17});
  note = loadAni("Assets/note.png", {width: 175, height: 248, frames: 14});
  idle = loadAni("Assets/idle.png", {width: 175, height: 248, frames: 18});
  
  nuhuh = loadSound("Sounds/angry.mp3");
  nuhuh.volume = 0.5;
  
  //Store Animations in Sprite Object with Aliases for easy Access and set fps
  stickman.addAni("angry", angry);
  stickman.addAni("lose", lose);
  stickman.addAni("note", note);
  //default is probably last inserted animation
  stickman.addAni("idle", idle);
  stickman.anis.frameDelay = 8;
}

function setup(){
  new Canvas(800, 248);
  //mad();
}

function draw(){
  clear();
  background("grey");
  //Only call ONCE no continous true input for calls or sequence won't start correctly
  //last animation is being looped by default
  //if "**"is set whole array is looped
  //if ";;" is set at the end the sequence and animation stops completely
  if (kb.presses('up')) {
    stickman.changeAni(["note", "lose", "idle"]);
    nuhuh.stop();
    console.log("hi");
  }
  
  if (kb.presses('down')) {
    stickman.changeAni("angry");
    nuhuh.loop();
    console.log("bye");
  }
    
}

/*
async function mad(){
  
  //play angry once
  await stickman.changeAni("angry");
  
  //then change to idle animation
  await stickman.changeAni("idle");
  
  mad();
}*/