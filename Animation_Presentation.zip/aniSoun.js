//Variables for Animations
let idleAni;
let noteAni;
let thinkAni;
let waitAni;
let angryAni;
let winAni;
let loseAni;
let climbAni;
let walkAni;
let waveAnim;


//Variables for Sounds;
let angrySoun;
let failSoun;
let thinkSoun;
let insertSoun;
let portalSoun;
let snakeIdSoun;
let snakeDeSoun;
let writeSoun;
let noteSoun;
let tappSoun;
let gateSoun;
let walkSoun;
let winSoun;
let waveSoun;


//make sure call is only once
let upLocked = false;
let stickman;

//show active Sound on Canvas
let activeSound;


function preload(){  
  //Create Sprite Object and set position
  stickman = new Sprite(175, 248);
  
  //load the sounds
  angrySoun = loadSound("Sounds/angry.mp3");
  failSoun = loadSound("Sounds/fail.mp3");
  thinkSoun = loadSound("Sounds/think.mp3");
  noteSoun = loadSound("Sounds/note.mp3");
  tappSoun = loadSound("Sounds/tapp.mp3");
  walkSoun = loadSound("Sounds/walk.mp3");
  winSoun = loadSound("Sounds/win.mp3");
  waveSoun = loadSound("Sounds/wave.mp3");
  climbSoun = loadSound("Sounds/climb.mp3");
  
  //Load Animations
  waveAni = loadAni("Assets/wave.png", {width: 175, height: 248, frames: 2});
  walkAni = loadAni("Assets/walk.png", {width: 175, height: 248, frames: 4});
  climbAni = loadAni("Assets/climb.png", {width: 175, height: 248, frames: 2});
  loseAni = loadAni("Assets/lose.png", {width: 175, height: 248, frames: 17});
  winAni =  loadAni("Assets/win.png", {width: 175, height: 248, frames: 11});
  angryAni = loadAni("Assets/angry.png", {width: 175, height: 248, frames: 11});
  waitAni = loadAni("Assets/wait.png", {width: 175, height: 248, frames: 10});
  thinkAni = loadAni("Assets/think.png", {width: 175, height: 248, frames: 11});
  noteAni = loadAni("Assets/note.png", {width: 175, height: 248, frames: 14});
  idleAni = loadAni("Assets/idle.png", {width: 175, height: 248, frames: 18});
  
  stickman.addAni("wave", waveAni);
  stickman.addAni("walk", walkAni);
  stickman.addAni("climb", climbAni);
  stickman.addAni("lose", loseAni);
  stickman.addAni("win", winAni);
  stickman.addAni("angry", angryAni);
  stickman.addAni("wait", waitAni);
  stickman.addAni("think", thinkAni);
  stickman.addAni("note", noteAni);
  stickman.addAni("idle", idleAni);
  stickman.anis.frameDelay = 9;
  stickman.scale = 2;
}


function setup(){
  new Canvas(175*2, 248*2);
}

function draw(){
  clear();
  //background("grey");
  
  if (!upLocked) {
    present();
    upLocked = true;
  }
}


async function present(){
  
  angrySoun.play();
  console.log("angry");
  await stickman.changeAni("angry");
  angrySoun.stop();
  
  failSoun.play();
  console.log("lose");
  await stickman.changeAni("lose");
  failSoun.stop();
  
  thinkSoun.play();
  console.log("think");
  await stickman.changeAni("think");
  thinkSoun.stop();
  
  noteSoun.play();
  console.log("note");
  await stickman.changeAni("note");
  noteSoun.stop();
  
  tappSoun.play();
  console.log("wait");
  await stickman.changeAni("wait");
  tappSoun.stop();
  
  walkSoun.play();
  console.log("walk");
  await stickman.changeAni(["walk", "walk", "walk", "walk", "walk", "walk"]);
  walkSoun.stop();
  
  winSoun.play();
  console.log("win");
  await stickman.changeAni("win");
  winSoun.stop();
  
  waveSoun.play();
  console.log("wave");
  await stickman.changeAni(["wave", "wave", "wave", "wave"]);
  waveSoun.stop();
  
  climbSoun.play();
  console.log("climb");
  await stickman.changeAni(["climb", "climb", "climb", "climb", "climb", "climb", "climb", "climb", "climb", "climb"]);
  climbSoun.stop();
  
  console.log("idle");
  await stickman.changeAni("idle");
  
  
  
  //make sure the looping stops when gameState is changed
  if(upLocked){
    console.log("presentation restart");
    return present();
  }
}